public class Licenciatura extends Titulo {

    public boolean CompareTo;
    private String temasDeTesis;
    private Integer fechaDeEntega;
    private Integer cantTrabajosInvestigados;

    //Constructor

    public Licenciatura(String temasDeTesis, Integer fechaDeEntega, Integer cantTrabajosInvestigados, String fechaInicioCarrera, String fechaFinalCarrera, Boolean selladoMinisterio, Boolean selladoInstituto, Persona persona) {
        super(fechaInicioCarrera, fechaFinalCarrera, selladoMinisterio, selladoInstituto, persona);
        this.temasDeTesis = temasDeTesis;
        this.fechaDeEntega = fechaDeEntega;
        this.cantTrabajosInvestigados = cantTrabajosInvestigados;

    }



    /* el uso seria
    Licenciatura titulo1 = new Licenciatura();
    Licenciatura titulo2 = new Licenciatura();
    titulo1.esMayorque(titulo2);
    */
     /*public Boolean esMayorQue(Licenciatura otroTitulo){
        System.out.println("titulos");
         return null;

      */

    //Metodo

    // CompareTo es una Interfaz 

    public int CompareTo(Object object) {
        Licenciatura otroTitulo = (Licenciatura) object;
        if (this.cantTrabajosInvestigados < otroTitulo.cantTrabajosInvestigados) return -1;
        else if (this.cantTrabajosInvestigados > otroTitulo.cantTrabajosInvestigados) return 1;
        return 0;


    }

}

