public class Main {
    public static void main(String[] args) {

        Persona persona1 = new Persona("Jose", "Jose", 32479687 , 29);
        Persona persona2 = new Persona("Jhonatan" , "Joestar", 000001, 17);


        Terciario terciario = new Terciario("2020", "2025", true, true, persona1, "nacional");
        Licenciatura licenciatura = new Licenciatura("Estuidio de las plantas", 2023, 5,"02/12/2017", "07/10/2023", true, false, persona2);

        System.out.println(licenciatura.CompareTo;.tipoValidacion);


    }
}