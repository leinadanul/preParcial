public class Persona {
    private String nombre;
    private String apellido;
    private Integer DNI;
    private Integer edad;

    //Constructor


    public Persona(String nombre, String apellido, Integer DNI, Integer edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.DNI = DNI;
        this.edad = edad;
    }
}
