public class Terciario extends Titulo{

    static String tipoValidacion;


    //Constructor


    public Terciario(String fechaInicioCarrera, String fechaFinalCarrera, Boolean selladoMinisterio, Boolean selladoInstituto, Persona persona, String tipoValidacion) {
        super(fechaInicioCarrera, fechaFinalCarrera, selladoMinisterio, selladoInstituto, persona);
        this.tipoValidacion = tipoValidacion;
    }



    //Metodo

    public static Boolean validoNivelNacional(Terciario terciario){
        if (tipoValidacion == "nacional"){
            return true;
        }
        else{
            return false;
        }
    }


}
