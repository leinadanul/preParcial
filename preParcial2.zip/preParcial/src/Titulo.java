public abstract class Titulo{

    private String fechaInicioCarrera;
    private String fechaFinalCarrera;
    private Boolean selladoMinisterio;
    private Boolean selladoInstituto;
    private Persona persona;


    //Constructor
    public  Titulo(String fechaInicioCarrera, String fechaFinalCarrera, Boolean selladoMinisterio, Boolean selladoInstituto,
                   Persona persona){
        this.fechaInicioCarrera = fechaInicioCarrera;
        this.fechaFinalCarrera = fechaFinalCarrera;
        this.selladoMinisterio = selladoMinisterio;
        this.selladoInstituto = selladoInstituto;
        this.persona = persona;
    }

    // METODO
    public  Boolean permiteEjercer(){
        if (this.selladoInstituto && this.selladoMinisterio){
            return true;
        }
        else{
            return false;

        }
    }

}
